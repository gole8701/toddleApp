import React, { useState, useRef } from "react";
import "./App.css";

function App() {
  const dragItem = useRef(null);
  const dragOverItem = useRef(null);
  const [inputCheck, setInputCheck] = useState({});
  const [original, setOriginal] = useState([
    {
      id: 1,
      text: "Numbers",
      shift: 0,
    },
    {
      id: 2,
      text: "Measurments",
      shift: 0,
    },
  ]);
  const [textColor, setTextColor] = useState({});

  const dragStart = (e, position) => {
    dragItem.current = position;
  };

  const dragEnter = (e, position) => {
    dragOverItem.current = position;
  };

  const handleSort = () => {
    const copyListItems = [...original];
    const dragItemContent = copyListItems[dragItem.current];
    copyListItems.splice(dragItem.current, 1);
    copyListItems.splice(dragOverItem.current, 0, dragItemContent);
    dragItem.current = null;
    dragOverItem.current = null;
    setOriginal(copyListItems);
  };

  const handleIndendOutdent = (obj, shiftChange) => {
    let tempData =
      shiftChange === "left" && obj.shift > -60
        ? obj.shift - 20
        : obj.shift + 20;
    const modifiedState = original.map((item) =>
      item.id === obj.id ? { ...item, shift: tempData } : item
    );
    setTextColor({ id: obj?.id, shiftVal: tempData });
    setOriginal(modifiedState);
  };

  const handleDelete = (idx) => {
    const deletedData = original.filter((del) => del.id !== idx);
    setOriginal(deletedData);
  };

  const handleAdd = (e) => {
    e.preventDefault();
    let num = Math.floor(Math.random() * 1000);
    setOriginal([
      ...original,
      {
        id: num,
        text: `standered mathematics text edit by double Click ${num}`,
        shift: 20,
      },
    ]);
  };

  const handleChange = (e, id) => {
    const update = original.map((val) => {
      if (val.id === id) {
        return { ...val, text: e.target.value };
      }
      return val;
    });
    setOriginal(update);
  };
  return (
    <div className="App">
      <h2>MATHEMATICS</h2>
      <hr />
      <div className="upperHeading">
        <div className="actions">
          <h4>Actions</h4>
          <p>
            Move,Ident,
            <br />
            Outdent,Delete
          </p>
        </div>
        <div className="actions">
          <h4>Standered</h4>
          <p>The text of the standered</p>
        </div>
      </div>
      {original &&
        original.map((text, index) => {
          return (
            <div
              key={text.id}
              className="list-main"
              onDragStart={(e) => dragStart(e, index)}
              onDragEnter={(e) => dragEnter(e, index)}
              onDragEnd={handleSort}
              onDragOver={(e) => e.preventDefault()}
              draggable
            >
              <div>
                <span className="icons">
                  <img src="/drag-move.svg" alt="move" />
                  <img
                    src="/arrow-left-line.svg"
                    onClick={() => handleIndendOutdent(text, "left")}
                    alt="left Arrow"
                  />
                  <img
                    src="/arrow-right-line.svg"
                    onClick={() => handleIndendOutdent(text, "right")}
                    alt="Right Arrow"
                  />
                  <img
                    src="/delete-bin.svg"
                    alt="delete"
                    onClick={() => handleDelete(text.id)}
                  />
                </span>
              </div>
              <div className="list-text">
                <div style={{ left: `${text?.shift}px` }}>
                  <div></div>
                  {inputCheck?.isTrue && inputCheck?.inputId === text?.id ? (
                    <input
                      type="text"
                      defaultValue={text?.text}
                      onChange={(e) => handleChange(e, text?.id)}
                      onBlur={() => setInputCheck({ isTrue: false })}
                    />
                  ) : (textColor.id === text.id && textColor.shiftVal) > 0 ? (
                    <span
                      onDoubleClick={() =>
                        setInputCheck({ isTrue: true, inputId: text?.id })
                      }
                      className="textIndent"
                    >
                      {text.text}
                    </span>
                  ) : (textColor.id === text.id && textColor.shiftVal) < 0 ? (
                    <span
                      onDoubleClick={() =>
                        setInputCheck({ isTrue: true, inputId: text?.id })
                      }
                      className="textOutdent"
                    >
                      {text.text}
                    </span>
                  ) : (
                    <span
                      onDoubleClick={() =>
                        setInputCheck({ isTrue: true, inputId: text?.id })
                      }
                      className="defaultColor"
                    >
                      {text.text}
                    </span>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      <button onClick={(e) => handleAdd(e)}>
        <img src="/add-circle.svg" alt="add" /> <span>Add A Standered</span>
      </button>
    </div>
  );
}

export default App;
